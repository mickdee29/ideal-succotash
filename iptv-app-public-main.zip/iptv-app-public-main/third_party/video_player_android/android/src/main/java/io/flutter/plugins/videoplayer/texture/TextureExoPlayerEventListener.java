// Copyright 2013 The Flutter Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

package io.flutter.plugins.videoplayer.texture;

import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.media3.common.Format;
import androidx.media3.common.VideoSize;
import androidx.media3.exoplayer.ExoPlayer;
import io.flutter.plugins.videoplayer.ExoPlayerEventListener;
import io.flutter.plugins.videoplayer.VideoPlayerCallbacks;
import java.util.Objects;

public final class TextureExoPlayerEventListener extends ExoPlayerEventListener {
  private final boolean surfaceProducerHandlesCropAndRotation;

  public TextureExoPlayerEventListener(
      @NonNull ExoPlayer exoPlayer,
      @NonNull VideoPlayerCallbacks events,
      boolean surfaceProducerHandlesCropAndRotation) {
    super(exoPlayer, events);
    this.surfaceProducerHandlesCropAndRotation = surfaceProducerHandlesCropAndRotation;
  }

  // Multiview (the only texture-player user): several streams share the
  // provider's connection limit, so a fatal-error recovery waits a moment
  // instead of reconnecting instantly (an instant retry can land while the
  // provider still counts the dropped socket), a live stream the server
  // simply closed is reconnected instead of sitting in ENDED forever, and a
  // tile whose hardware decoder stops producing frames is restarted.
  @Override
  protected long errorRetryDelayMs() {
    return 2_000;
  }

  @Override
  protected boolean reconnectWhenLiveEnds() {
    return true;
  }

  @Override
  protected boolean recoverFrozenVideo() {
    return true;
  }

  @Override
  protected void sendInitialized() {
    VideoSize videoSize = exoPlayer.getVideoSize();
    RotationDegrees rotationCorrection = RotationDegrees.ROTATE_0;
    int width = videoSize.width;
    int height = videoSize.height;
    if (width != 0 && height != 0) {
      // Anamorphic content is stored with non-square pixels, so the coded width has to be
      // scaled by the pixel aspect ratio to obtain the display width. ExoPlayer reports a
      // pixelWidthHeightRatio that already accounts for any applied rotation, so this is
      // correct regardless of the rotation correction computed below.
      // Clamped to at least one pixel so that a malformed ratio cannot report a zero width.
      float pixelWidthHeightRatio = videoSize.pixelWidthHeightRatio;
      if (pixelWidthHeightRatio > 0 && pixelWidthHeightRatio != 1f) {
        width = Math.max(1, Math.round(width * pixelWidthHeightRatio));
      }

      // When the SurfaceTexture backend for Impeller is used, the preview should already
      // be correctly rotated.
      if (!surfaceProducerHandlesCropAndRotation) {
        // The video's Format also provides a rotation correction that may be used to
        // correct the rotation, so we try to use that to correct the video rotation
        // when the ImageReader backend for Impeller is used.
        int rawVideoFormatRotation = getRotationCorrectionFromFormat(exoPlayer);

        try {
          rotationCorrection = RotationDegrees.fromDegrees(rawVideoFormatRotation);
        } catch (IllegalArgumentException e) {
          // Rotation correction other than 0, 90, 180, 270 reported by Format. Because this is
          // unexpected we apply no rotation correction.
          rotationCorrection = RotationDegrees.ROTATE_0;
        }
      }
    }
    events.onInitialized(width, height, exoPlayer.getDuration(), rotationCorrection.getDegrees());
  }

  @OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
  // A video's Format and its rotation degrees are unstable because they are not guaranteed
  // the same implementation across API versions. It is possible that this logic may need
  // revisiting should the implementation change across versions of the Exoplayer API.
  private int getRotationCorrectionFromFormat(ExoPlayer exoPlayer) {
    Format videoFormat = Objects.requireNonNull(exoPlayer.getVideoFormat());
    return videoFormat.rotationDegrees;
  }
}
